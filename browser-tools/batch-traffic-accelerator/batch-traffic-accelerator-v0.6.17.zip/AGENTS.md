# Repository Instructions

- Every extension update must update `PRD.md`, `TECHNICAL_DESIGN.md`, `README.md`, and `IMPLEMENTATION_PATH.md` as applicable.
- Bump the version in `manifest.json` for every delivered extension update.
- Run syntax checks, import tests, UI tests, extension tests, and applicable real-page tests before publishing.
- Package releases as `batch-traffic-accelerator-v<version>.zip`.
- Sync the release to the currently loaded unpacked extension directory and reload it before reporting completion.
- Preserve user-imported Excel data and never modify source workbooks.
- Document unresolved root causes as open issues instead of presenting guesses as confirmed fixes.
