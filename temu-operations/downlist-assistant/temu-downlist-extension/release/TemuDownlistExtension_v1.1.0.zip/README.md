# Temu 下架与主图归档扩展

![界面预览](preview.png)

该工具由两部分组成：

- Chrome MV3 扩展：读取 Excel、查询 Temu、归档主图、填写下架表单并核验结果。
- Windows 本地助手：在桌面创建固定目录，下载并校验主图，保存结果 Excel。

本地助手同时提供 Native Messaging 和仅限本机访问的 HTTP 接口。如果当前比特浏览器版本不识别 Native Messaging，扩展会自动改用 `127.0.0.1:17866`，并在请求中校验固定扩展来源和令牌。

## 输出结构

```text
桌面/
└── 下架图片合集/
    └── CXTX/
        ├── 主图保存/
        │   └── 8780418723_主图_01.jpeg
        └── 背面图保存/
```

分类默认从页面货号自动提取：

```text
CXTX9 → CXTX
```

程序不会下载、修改、重命名或覆盖“背面图保存”中的模板。

## Excel 格式

第一行为表头：

| A | B | C |
|---|---|---|
| 序号 | SPU ID | 状态 |

SPU 必须按文本保存，避免 Excel 将长编号转为科学计数法。程序会读取状态列，已标记成功的行默认跳过，并导出新的结果 Excel。旧版 SKC 输入表仍可兼容读取。

空白模板位于 `templates\SPU导入模板.xlsx`。

## 安装

### 1. 安装本地助手

在 PowerShell 中运行：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\native\install-native-host.ps1
```

也可以直接双击 `install.cmd`。

脚本会：

- 编译 `TemuDownlistHelper.exe`。
- 复制到 `%LOCALAPPDATA%\TemuDownlistExtension\native`。
- 注册 Chrome、Chromium 和 BitBrowser 的 Native Messaging Host。
- 创建 Windows 登录启动快捷方式，并在安装后立即启动本地助手。

扩展 ID 固定为：

```text
mcgadkimbdnkdmcchihilkaghjefklpo
```

安装或更新本地助手后，需要完全退出并重新打开比特浏览器。

### 2. 加载扩展

1. 在目标比特浏览器窗口打开 `chrome://extensions/`。
2. 打开右上角“开发者模式”。
3. 点击“加载未打包的扩展程序”。
4. 选择本目录：`temu-downlist-extension`。
5. 将“Temu 下架与主图归档”固定到工具栏。
6. 打开或刷新“商品管理 → 图片/视频更新任务全球”。
7. 页面右侧会自动出现“Temu 下架助手”悬浮面板；最小化后可通过“下架助手”按钮恢复。

## 使用

1. 点击“检查”，确认本地助手、比特窗口和 Temu 页面均为绿色。
2. 选择处理模式：

   - “仅保存主图”：演练模式，不提交下架。
   - “保存主图并下架”：真实下架，必须勾选最终授权。

3. 如页面货号无法自动提取分类，可填写“货号分类覆盖”，例如 `CXTX`。
4. 导入 Excel。
5. 点击“开始处理”。
6. 完成后查看 `桌面\下架图片合集\处理结果_时间.xlsx`。

## 处理逻辑

- 查询类型自动切换为 SPU。
- 每次只查询一个 SPU 并等待结果。
- 从查询结果提取 SPU、货号和货品 SKC。
- 按 SPU 去重主图，同 SPU 只保存一次。
- 主图下载后校验尺寸、格式和 SHA256。
- 下架原因固定为“亏损下架”。
- 平台返回系统忙碌时最多重试 3 次，间隔 15 秒。
- 下架成功后进入商品列表“已下架/已终止”分类核验。

## 结果状态

- 演练完成（主图成功）
- 下架成功
- 下架成功（已核验）
- 未查到
- 需复核
- 处理失败

## 故障排查

本地助手日志：

```text
%LOCALAPPDATA%\TemuDownlistHelper\helper.log
```

Native Host 清单：

```text
%LOCALAPPDATA%\TemuDownlistExtension\native\com.jlkj.temu_downlist.json
```

如果“本地助手”显示未安装：

1. 重新运行安装脚本。
2. 确认扩展 ID 仍为 `mcgadkimbdnkdmcchihilkaghjefklpo`。
3. 完全退出所有比特浏览器进程后重新打开。
4. 在扩展管理页点击本扩展的“重新加载”。

## 卸载

卸载本地助手：

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\native\uninstall-native-host.ps1
```

然后在 `chrome://extensions/` 中移除本扩展。桌面已保存的主图、背图模板和结果文件不会被删除。

## 安全说明

- 不读取或导出比特浏览器账号密码、Cookie。
- 本地助手只允许写入桌面的“下架图片合集”。
- 图片只允许从 `*.kwcdn.com` 的 HTTPS 地址下载。
- 真实下架默认要求用户勾选授权并再次确认。
- “背面图保存”目录不会被程序写入。
