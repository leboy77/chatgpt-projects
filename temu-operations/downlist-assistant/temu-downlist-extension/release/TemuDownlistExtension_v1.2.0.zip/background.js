importScripts("shared.js");

const {
  DEFAULT_BROWSER_ID,
  NATIVE_HOST,
  HELPER_HTTP_URL,
  HELPER_TOKEN
} = TemuCommon;

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.local.get("browserId");
  if (!stored.browserId) {
    await chrome.storage.local.set({ browserId: DEFAULT_BROWSER_ID });
  }
  await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
});

chrome.runtime.onStartup.addListener(() => {
  chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "openBitBrowserProfile") {
    openBitBrowserProfile(message.browserId || DEFAULT_BROWSER_ID)
      .then((data) => sendResponse({ ok: true, data }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }

  if (message?.type === "native") {
    helperRequest(message.payload || {})
      .then((data) => sendResponse({ ok: true, data }))
      .catch((error) =>
        sendResponse({
          ok: false,
          error:
            error?.message ||
            "本地助手未运行。请安装本地助手或重新启动比特浏览器。"
        })
      );
    return true;
  }

  if (message?.type === "injectMainWorldBridge" && _sender.tab?.id) {
    chrome.scripting
      .executeScript({
        target: { tabId: _sender.tab.id },
        world: "MAIN",
        files: ["page-bridge.js"]
      })
      .then(() => sendResponse({ ok: true }))
      .catch((error) => sendResponse({ ok: false, error: error.message }));
    return true;
  }
});

async function helperRequest(payload) {
  let httpError = null;
  try {
    const response = await fetch(`${HELPER_HTTP_URL}/rpc`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "X-Temu-Helper-Token": HELPER_TOKEN
      },
      body: JSON.stringify(payload)
    });
    if (!response.ok) {
      throw new Error(`本地助手 HTTP ${response.status}`);
    }
    return await response.json();
  } catch (error) {
    httpError = error;
  }

  try {
    return await chrome.runtime.sendNativeMessage(NATIVE_HOST, payload);
  } catch (nativeError) {
    throw new Error(
      `本地助手不可用。${httpError?.message || ""}；${nativeError?.message || ""}`.trim()
    );
  }
}

async function openBitBrowserProfile(browserId) {
  const response = await fetch("http://127.0.0.1:54345/browser/open", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ id: browserId })
  });

  if (!response.ok) {
    throw new Error(`比特浏览器 API 返回 HTTP ${response.status}`);
  }

  const result = await response.json();
  if (!result?.success) {
    throw new Error(result?.msg || result?.message || "比特浏览器窗口打开失败");
  }

  return result.data || {};
}
