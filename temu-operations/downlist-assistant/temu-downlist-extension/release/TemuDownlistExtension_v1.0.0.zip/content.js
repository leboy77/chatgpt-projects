(function initTemuContentScript() {
  if (globalThis.__temuDownlistContentLoaded) return;
  globalThis.__temuDownlistContentLoaded = true;

  const {
    normalizeText,
    stripImageQuery,
    sleep
  } = TemuCommon;

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (!message?.type) return false;

    let task;
    if (message.type === "contentPing") {
      sendResponse({
        ok: true,
        url: location.href,
        title: document.title,
        ready: true
      });
      return false;
    }

    if (message.type === "searchAndExtract") {
      task = searchAndExtract(message);
    } else if (message.type === "downlistSkc") {
      task = downlistSkc(message);
    } else if (message.type === "testDownlistForm") {
      task = testDownlistForm(message);
    } else if (message.type === "verifyDownlisted") {
      task = verifyDownlisted(message);
    } else {
      return false;
    }

    task
      .then((result) => sendResponse({ ok: true, data: result }))
      .catch((error) =>
        sendResponse({
          ok: false,
          code: error.code || "CONTENT_SCRIPT_ERROR",
          error: error.message || String(error)
        })
      );
    return true;
  });

  function scriptError(code, message) {
    const error = new Error(message);
    error.code = code;
    return error;
  }

  function isVisible(element) {
    if (!element || !element.isConnected) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return (
      style.display !== "none" &&
      style.visibility !== "hidden" &&
      Number(style.opacity) !== 0 &&
      rect.width > 1 &&
      rect.height > 1
    );
  }

  function allElements(root = document) {
    return [...root.querySelectorAll("*")];
  }

  function leafByExactText(text, root = document) {
    const expected = normalizeText(text);
    return allElements(root).filter(
      (element) =>
        element.children.length === 0 &&
        isVisible(element) &&
        normalizeText(element.textContent) === expected
    );
  }

  function clickableAncestor(element) {
    let cursor = element;
    for (let depth = 0; cursor && depth < 8; depth += 1) {
      const tag = cursor.tagName?.toLowerCase();
      const role = cursor.getAttribute?.("role");
      const style = getComputedStyle(cursor);
      if (
        tag === "button" ||
        tag === "a" ||
        role === "button" ||
        style.cursor === "pointer"
      ) {
        return cursor;
      }
      cursor = cursor.parentElement;
    }
    return element;
  }

  function dispatchMouseClick(element) {
    if (!element) return false;
    element.scrollIntoView({ block: "center", inline: "center" });
    for (const type of ["mousedown", "mouseup", "click"]) {
      element.dispatchEvent(
        new MouseEvent(type, {
          bubbles: true,
          cancelable: true,
          view: window,
          button: 0
        })
      );
    }
    return true;
  }

  function clickExactText(text, root = document, options = {}) {
    const candidates = leafByExactText(text, root);
    if (!candidates.length) return false;
    const ordered = options.last ? candidates.reverse() : candidates;
    for (const candidate of ordered) {
      const clickable = clickableAncestor(candidate);
      if (clickable && isVisible(clickable)) {
        dispatchMouseClick(clickable);
        return true;
      }
    }
    return false;
  }

  function clickTextPrefix(prefix, root = document) {
    const expected = normalizeText(prefix);
    const candidates = allElements(root).filter(
      (element) =>
        element.children.length === 0 &&
        isVisible(element) &&
        normalizeText(element.textContent).startsWith(expected)
    );
    for (const candidate of candidates) {
      const clickable = clickableAncestor(candidate);
      if (clickable && isVisible(clickable)) {
        dispatchMouseClick(clickable);
        return true;
      }
    }
    return false;
  }

  function findInputByPlaceholder(fragment, root = document) {
    const needle = normalizeText(fragment);
    return allElements(root)
      .filter((element) => element.matches?.("input,textarea") && isVisible(element))
      .find((element) => normalizeText(element.placeholder).includes(needle));
  }

  function setNativeInputValue(input, value) {
    if (!input) return false;
    input.focus();
    input.select?.();
    try {
      document.execCommand("selectAll", false);
      document.execCommand("insertText", false, String(value));
    } catch (_) {
      // fall through
    }

    if (input.value !== String(value)) {
      const prototype =
        input instanceof HTMLTextAreaElement
          ? HTMLTextAreaElement.prototype
          : HTMLInputElement.prototype;
      const setter = Object.getOwnPropertyDescriptor(prototype, "value")?.set;
      setter?.call(input, String(value));
    }

    input.dispatchEvent(
      new InputEvent("input", {
        bubbles: true,
        cancelable: false,
        inputType: "insertText",
        data: String(value)
      })
    );
    input.dispatchEvent(new Event("change", { bubbles: true }));
    return input.value === String(value);
  }

  async function waitFor(check, timeoutMs = 15000, intervalMs = 160) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      try {
        const result = check();
        if (result) return result;
      } catch (_) {
        // Keep waiting; React may temporarily detach nodes.
      }
      await sleep(intervalMs);
    }
    return null;
  }

  function visibleText() {
    return normalizeText(document.body?.innerText || "");
  }

  function hasNoResultsText() {
    return /暂无数据|暂无结果|未查询到|没有查询到|无符合条件/.test(visibleText());
  }

  async function ensureSkcQueryType(timeoutMs = 5000) {
    const getSelect = () =>
      allElements()
        .filter(
          (element) =>
            element.matches?.("input") &&
            isVisible(element) &&
            ["SPU", "SKC"].includes(normalizeText(element.value))
        )
        .find(Boolean);

    const select = getSelect();
    if (!select) throw scriptError("QUERY_TYPE_NOT_FOUND", "未找到 SPU/SKC 查询类型下拉框");
    if (normalizeText(select.value) === "SKC") return true;

    dispatchMouseClick(select.parentElement);
    const option = await waitFor(() => {
      return allElements()
        .filter(
          (element) =>
            element.matches?.('li[role="option"]') &&
            isVisible(element) &&
            normalizeText(element.textContent) === "SKC"
        )
        .find(Boolean);
    }, timeoutMs);

    if (!option) throw scriptError("SKC_OPTION_NOT_FOUND", "查询类型未找到 SKC 选项");
    dispatchMouseClick(option);

    const changed = await waitFor(
      () => normalizeText(getSelect()?.value) === "SKC",
      timeoutMs
    );
    if (!changed) throw scriptError("SKC_OPTION_CHANGE_FAILED", "查询类型未能切换为 SKC");
    return true;
  }

  function findResultRow(skc) {
    const skcPattern = new RegExp(`货品SKC[：:]\\s*${skc}`);
    const candidates = allElements().filter((element) => {
      if (!isVisible(element)) return false;
      const text = normalizeText(element.innerText);
      return (
        text.length < 2500 &&
        skcPattern.test(text) &&
        /SPU[：:]\s*\d+/.test(text) &&
        /货号[：:]\s*[^\s]+/.test(text)
      );
    });

    candidates.sort((left, right) => {
      const leftRect = left.getBoundingClientRect();
      const rightRect = right.getBoundingClientRect();
      return leftRect.width * leftRect.height - rightRect.width * rightRect.height;
    });
    return candidates[0] || null;
  }

  function extractMainImage(row) {
    const images = [...row.querySelectorAll("img")]
      .filter((image) => {
        const source = image.currentSrc || image.src || "";
        return isVisible(image) && /img\d*\.kwcdn\.com\/product\//.test(source);
      })
      .map((image) => {
        const rect = image.getBoundingClientRect();
        return {
          source: image.currentSrc || image.src,
          area: rect.width * rect.height,
          x: rect.x
        };
      })
      .sort((left, right) => right.area - left.area || left.x - right.x);

    return images[0]?.source || "";
  }

  async function searchAndExtract({ skc, timeoutMs = 22000 }) {
    const cleanSkc = String(skc || "").trim();
    if (!/^\d{8,20}$/.test(cleanSkc)) {
      throw scriptError("SKC_INVALID", `SKC 格式异常：${cleanSkc || "空"}`);
    }
    if (!location.href.includes("/material/image-task")) {
      throw scriptError("WRONG_PAGE", "当前不是图片/视频更新任务页面");
    }

    await ensureSkcQueryType();
    const input = findInputByPlaceholder("批量查询按照空格/逗号");
    if (!input) throw scriptError("QUERY_INPUT_NOT_FOUND", "未找到 SKC 查询输入框");
    setNativeInputValue(input, cleanSkc);
    await sleep(180);

    if (!clickExactText("查询")) {
      throw scriptError("QUERY_BUTTON_NOT_FOUND", "未找到查询按钮");
    }

    const queryStartedAt = Date.now();
    await sleep(500);
    const outcome = await waitFor(() => {
      const row = findResultRow(cleanSkc);
      if (row) return { type: "found", row };
      if (Date.now() - queryStartedAt >= 2500 && hasNoResultsText()) {
        return { type: "empty" };
      }
      return null;
    }, timeoutMs);

    if (!outcome) {
      throw scriptError("SEARCH_TIMEOUT", `查询 SKC ${cleanSkc} 超时`);
    }
    if (outcome.type === "empty") {
      return { found: false, skc: cleanSkc, reason: "NO_RESULT" };
    }

    const rowText = normalizeText(outcome.row.innerText);
    const spu = rowText.match(/SPU[：:]\s*(\d+)/)?.[1] || "";
    const goodsCode = rowText.match(/货号[：:]\s*([^\s]+)/)?.[1] || "";
    const pageSkc =
      rowText.match(/货品SKC[：:]\s*(\d+)/)?.[1] || "";
    const imageUrl = extractMainImage(outcome.row);

    if (!spu || !goodsCode || !pageSkc) {
      throw scriptError(
        "EXTRACT_FAILED",
        `查询成功但字段不完整：SPU=${spu || "-"}，货号=${goodsCode || "-"}，SKC=${pageSkc || "-"}`
      );
    }
    if (pageSkc !== cleanSkc) {
      throw scriptError(
        "SKC_MISMATCH",
        `输入 SKC ${cleanSkc}，页面返回 ${pageSkc}`
      );
    }
    if (!imageUrl) {
      throw scriptError("MAIN_IMAGE_MISSING", "查询结果中未找到主图");
    }

    return {
      found: true,
      skc: pageSkc,
      spu,
      goodsCode,
      mainImageUrl: stripImageQuery(imageUrl),
      rowText
    };
  }

  function findCustomerTextArea() {
    return findInputByPlaceholder("请用文字简单描述你遇到的问题");
  }

  function findFormModal() {
    const titleNodes = leafByExactText("发送下架商品信息");
    const title = titleNodes.find(Boolean);
    if (title) {
      let cursor = title;
      for (let depth = 0; cursor && depth < 8; depth += 1) {
        if (
          cursor.innerText?.includes("下架原因") &&
          cursor.querySelector?.('input[placeholder="请输入完整SKC ID"]')
        ) {
          return cursor;
        }
        cursor = cursor.parentElement;
      }
    }

    const input = findInputByPlaceholder("请输入完整SKC ID");
    if (!input) return null;
    let cursor = input;
    for (let depth = 0; cursor && depth < 8; depth += 1) {
      if (cursor.innerText?.includes("下架原因")) return cursor;
      cursor = cursor.parentElement;
    }
    return null;
  }

  function findReasonControl(modal) {
    const labels = leafByExactText("下架原因", modal);
    for (const label of labels) {
      let cursor = label;
      for (let depth = 0; cursor && depth < 5; depth += 1) {
        const controls = [
          ...cursor.querySelectorAll?.('input[readonly], [role="combobox"]') || []
        ].filter(isVisible);
        if (controls.length) return controls[controls.length - 1];
        cursor = cursor.parentElement;
      }
    }

    const readonlyInputs = [
      ...modal.querySelectorAll('input[readonly], [role="combobox"]')
    ].filter(isVisible);
    return readonlyInputs[readonlyInputs.length - 1] || null;
  }

  async function openDownlistForm() {
    let modal = findFormModal();
    if (modal) return modal;

    const hasCustomerWidget =
      leafByExactText("官方客服").length > 0 ||
      leafByExactText("智能客服Mumu").length > 0 ||
      Boolean(findCustomerTextArea());

    if (!hasCustomerWidget) {
      clickExactText("客服");
      await waitFor(
        () =>
          leafByExactText("官方客服").length > 0 ||
          Boolean(findCustomerTextArea()),
        6000
      );
    }

    if (!findCustomerTextArea()) {
      if (clickExactText("联系官方客服", document, { last: true })) {
        await waitFor(
          () =>
            Boolean(findCustomerTextArea()) ||
            leafByExactText("发商品").some(isVisible),
          15000
        );
      }
    }

    if (!leafByExactText("发商品").length) {
      const textarea = findCustomerTextArea();
      if (textarea) {
        setNativeInputValue(textarea, "商品下架");
        const sendButton = leafByExactText("发送")
          .map(clickableAncestor)
          .find(isVisible);
        if (sendButton) dispatchMouseClick(sendButton);
      } else {
        clickExactText("商品下架", document, { last: true });
      }

      await waitFor(
        () => leafByExactText("发商品").some(isVisible),
        15000
      );
    }

    if (!clickExactText("发商品", document, { last: true })) {
      throw scriptError("SEND_GOODS_LINK_NOT_FOUND", "未找到“发商品”入口");
    }

    modal = await waitFor(findFormModal, 8000);
    if (!modal) throw scriptError("DOWNLIST_FORM_NOT_OPEN", "下架商品表单未打开");
    return modal;
  }

  function countOccurrences(text, needle) {
    if (!needle) return 0;
    return String(text).split(needle).length - 1;
  }

  function findConfirmDialog() {
    const title = leafByExactText("确认下架？").find(Boolean);
    if (!title) return null;
    let cursor = title;
    for (let depth = 0; cursor && depth < 8; depth += 1) {
      if (
        normalizeText(cursor.innerText).includes("可能因各类因素影响") &&
        [...cursor.querySelectorAll("button")].some(isVisible)
      ) {
        return cursor;
      }
      cursor = cursor.parentElement;
    }
    return null;
  }

  async function selectLossReason(modal) {
    const control = findReasonControl(modal);
    if (!control) throw scriptError("REASON_CONTROL_NOT_FOUND", "未找到下架原因选择框");
    dispatchMouseClick(control.parentElement || control);

    const option = await waitFor(
      () =>
        allElements()
          .filter(
            (element) =>
              element.matches?.('li[role="option"]') &&
              isVisible(element) &&
              normalizeText(element.textContent) === "亏损下架"
          )
          .find(Boolean),
      5000
    );
    if (!option) throw scriptError("LOSS_REASON_NOT_FOUND", "下架原因中没有“亏损下架”");
    dispatchMouseClick(option);
    await sleep(220);
  }

  async function waitAndConfirmDialog() {
    const dialog = await waitFor(findConfirmDialog, 8000);
    if (!dialog) throw scriptError("CONFIRM_DIALOG_NOT_FOUND", "未出现二次确认窗口");

    const button = await waitFor(() => {
      const candidates = [...dialog.querySelectorAll("button,a")]
        .filter(isVisible)
        .filter((element) => /^确认/.test(normalizeText(element.innerText)));
      const candidate = candidates[candidates.length - 1];
      if (!candidate) return null;
      const disabled =
        candidate.disabled ||
        candidate.getAttribute("aria-disabled") === "true" ||
        /\(\d+s\)/.test(normalizeText(candidate.innerText));
      return disabled ? null : candidate;
    }, 12000);

    if (!button) throw scriptError("CONFIRM_BUTTON_DISABLED", "最终确认按钮不可用");
    dispatchMouseClick(button);
  }

  async function downlistSkc({ skc, authorized, resultTimeoutMs = 90000 }) {
    const cleanSkc = String(skc || "").trim();
    if (!authorized) {
      throw scriptError("DOWNLIST_NOT_AUTHORIZED", "未获得最终下架提交授权");
    }
    if (!/^\d{8,20}$/.test(cleanSkc)) {
      throw scriptError("SKC_INVALID", `SKC 格式异常：${cleanSkc || "空"}`);
    }

    const modal = await openDownlistForm();
    const input = findInputByPlaceholder("请输入完整SKC ID", modal);
    if (!input) throw scriptError("SKC_INPUT_NOT_FOUND", "下架表单中未找到 SKC 输入框");
    setNativeInputValue(input, cleanSkc);
    await selectLossReason(modal);

    const successText = `【SKC ID：${cleanSkc}】：您好，该商品已下架`;
    const busyText = "非常抱歉操作失败，系统忙碌中，请您稍后重试";
    const beforeText = document.body.innerText || "";
    const baselineSuccess = countOccurrences(beforeText, successText);
    const baselineBusy = countOccurrences(beforeText, busyText);
    const baselineLength = beforeText.length;

    if (!clickExactText("申请下架", modal, { last: true })) {
      throw scriptError("SUBMIT_BUTTON_NOT_FOUND", "未找到“申请下架”按钮");
    }
    await waitAndConfirmDialog();

    const outcome = await waitFor(() => {
      const text = document.body.innerText || "";
      if (countOccurrences(text, successText) > baselineSuccess) {
        return { outcome: "success", message: successText };
      }
      if (countOccurrences(text, busyText) > baselineBusy) {
        return { outcome: "busy", message: busyText };
      }
      return null;
    }, resultTimeoutMs, 300);

    if (outcome) return { skc: cleanSkc, ...outcome };

    const afterText = document.body.innerText || "";
    const delta = afterText.startsWith(beforeText)
      ? afterText.slice(baselineLength)
      : afterText.slice(-1200);
    return {
      skc: cleanSkc,
      outcome: "timeout",
      message: `等待平台结果超时。页面新增内容：${normalizeText(delta).slice(0, 500)}`
    };
  }

  async function testDownlistForm({ skc }) {
    const cleanSkc = String(skc || "").trim();
    const modal = await openDownlistForm();
    const input = findInputByPlaceholder("请输入完整SKC ID", modal);
    if (!input) throw scriptError("SKC_INPUT_NOT_FOUND", "下架表单中未找到 SKC 输入框");
    setNativeInputValue(input, cleanSkc);
    await selectLossReason(modal);
    const reasonControl = findReasonControl(modal);
    const result = {
      opened: true,
      skcValue: input.value,
      reasonValue: reasonControl?.value || ""
    };
    if (!clickExactText("取消", modal, { last: true })) {
      throw scriptError("CANCEL_BUTTON_NOT_FOUND", "下架表单未找到取消按钮");
    }
    result.cancelled = true;
    return result;
  }

  function findProductListTypeSelect() {
    return allElements()
      .filter(
        (element) =>
          element.matches?.("input") &&
          isVisible(element) &&
          ["SPU", "SKC"].includes(normalizeText(element.value))
      )
      .find(Boolean);
  }

  function findProductListRow(skc) {
    const candidates = allElements().filter((element) => {
      if (!isVisible(element)) return false;
      const text = normalizeText(element.innerText);
      return (
        text.length < 6000 &&
        text.includes(String(skc)) &&
        /SPU ID[：:]/.test(text) &&
        /SKC ID[：:]/.test(text)
      );
    });
    candidates.sort((left, right) => {
      const a = left.getBoundingClientRect();
      const b = right.getBoundingClientRect();
      return a.width * a.height - b.width * b.height;
    });
    return candidates[0] || null;
  }

  async function verifyDownlisted({ skc, timeoutMs = 25000 }) {
    if (!location.href.includes("/goods/list")) {
      throw scriptError("WRONG_PAGE", "当前不是商品列表页面");
    }

    const typeSelect = findProductListTypeSelect();
    if (typeSelect && normalizeText(typeSelect.value) !== "SKC") {
      dispatchMouseClick(typeSelect.parentElement);
      const option = await waitFor(
        () =>
          allElements()
            .filter(
              (element) =>
                element.matches?.('li[role="option"]') &&
                isVisible(element) &&
                normalizeText(element.textContent) === "SKC"
            )
            .find(Boolean),
        5000
      );
      if (option) dispatchMouseClick(option);
    }

    const input = findInputByPlaceholder("多个查询请空格或逗号");
    if (!input) throw scriptError("PRODUCT_QUERY_INPUT_NOT_FOUND", "商品列表未找到查询输入框");
    setNativeInputValue(input, String(skc));
    await sleep(150);
    if (!clickExactText("查询")) {
      throw scriptError("PRODUCT_QUERY_BUTTON_NOT_FOUND", "商品列表未找到查询按钮");
    }

    await sleep(500);
    const foundRow = await waitFor(() => findProductListRow(skc), timeoutMs);
    if (!foundRow) {
      return { skc: String(skc), verified: false, reason: "ROW_NOT_FOUND" };
    }

    if (!clickTextPrefix("已下架/已终止")) {
      return {
        skc: String(skc),
        verified: false,
        reason: "STATUS_TAB_NOT_FOUND"
      };
    }
    await sleep(1800);

    const verified = Boolean(await waitFor(() => findProductListRow(skc), 10000));
    return {
      skc: String(skc),
      verified,
      rowText: normalizeText(findProductListRow(skc)?.innerText || "").slice(0, 1000)
    };
  }
})();
