(function initSidePanel() {
  const {
    IMAGE_TASK_URL,
    PRODUCT_LIST_URL,
    normalizeHeader,
    normalizeText,
    deriveCategoryCode,
    inferImageExtension,
    statusIsSuccessful,
    formatDateTime,
    sleep
  } = TemuCommon;

  const state = {
    workbook: null,
    originalAoa: [],
    fileName: "",
    sheetName: "",
    columns: { serial: 0, input: 1, status: 2 },
    lookupType: "SPU",
    rows: [],
    mode: "images",
    override: "",
    running: false,
    paused: false,
    stopping: false,
    workTabId: null,
    progressCurrent: 0,
    progressTotal: 0,
    lastResultPath: ""
  };

  const elements = {
    browserIdInput: document.getElementById("browserIdInput"),
    categoryOverrideInput: document.getElementById("categoryOverrideInput"),
    checkEnvironmentBtn: document.getElementById("checkEnvironmentBtn"),
    nativeDot: document.getElementById("nativeDot"),
    nativeStatus: document.getElementById("nativeStatus"),
    browserDot: document.getElementById("browserDot"),
    browserStatus: document.getElementById("browserStatus"),
    pageDot: document.getElementById("pageDot"),
    pageStatus: document.getElementById("pageStatus"),
    profileDetail: document.getElementById("profileDetail"),
    authorizeWrap: document.getElementById("authorizeWrap"),
    authorizeSubmitInput: document.getElementById("authorizeSubmitInput"),
    excelInput: document.getElementById("excelInput"),
    fileMeta: document.getElementById("fileMeta"),
    totalCount: document.getElementById("totalCount"),
    pendingCount: document.getElementById("pendingCount"),
    successCount: document.getElementById("successCount"),
    errorCount: document.getElementById("errorCount"),
    runState: document.getElementById("runState"),
    progressText: document.getElementById("progressText"),
    progressBar: document.getElementById("progressBar"),
    startBtn: document.getElementById("startBtn"),
    pauseBtn: document.getElementById("pauseBtn"),
    stopBtn: document.getElementById("stopBtn"),
    exportBtn: document.getElementById("exportBtn"),
    rowsBody: document.getElementById("rowsBody"),
    logOutput: document.getElementById("logOutput"),
    clearLogBtn: document.getElementById("clearLogBtn")
  };

  const THEMES = ["classic", "ocean", "forest", "sunset"];

  function applyTheme(theme, persist = true) {
    const nextTheme = THEMES.includes(theme) ? theme : "classic";
    document.documentElement.dataset.theme = nextTheme;
    document.querySelectorAll(".skin-swatch").forEach((button) => {
      button.setAttribute(
        "aria-pressed",
        button.dataset.theme === nextTheme ? "true" : "false"
      );
    });
    try {
      window.parent?.postMessage(
        { source: "temu-downlist-frame", type: "theme", theme: nextTheme },
        "*"
      );
    } catch (_) {
      // The UI is also usable as a normal extension page.
    }
    if (persist) {
      chrome.storage.local.set({ skin: nextTheme }).catch(() => {});
    }
  }

  function log(message, level = "info") {
    const stamp = new Date().toLocaleTimeString("zh-CN", { hour12: false });
    const prefix = level === "error" ? "错误" : level === "warn" ? "提醒" : "信息";
    elements.logOutput.textContent += `[${stamp}] ${prefix}：${message}\n`;
    elements.logOutput.scrollTop = elements.logOutput.scrollHeight;
  }

  function setDot(element, status) {
    element.classList.remove("ok", "error");
    if (status === "ok") element.classList.add("ok");
    if (status === "error") element.classList.add("error");
  }

  function setRunState(text) {
    elements.runState.textContent = text;
  }

  function setButtons() {
    elements.startBtn.disabled = state.running || !state.rows.length;
    elements.pauseBtn.disabled = !state.running;
    elements.pauseBtn.textContent = state.paused ? "继续" : "暂停";
    elements.stopBtn.disabled = !state.running;
    elements.exportBtn.disabled = !state.originalAoa.length || state.running;
  }

  function refreshProgress() {
    const percent = state.progressTotal
      ? Math.round((state.progressCurrent / state.progressTotal) * 100)
      : 0;
    elements.progressBar.style.width = `${Math.min(100, percent)}%`;
    elements.progressText.textContent = `${state.progressCurrent} / ${state.progressTotal}`;
    refreshCounts();
  }

  function refreshCounts() {
    const total = state.rows.length;
    const success = state.rows.filter((row) =>
      /主图成功|下架成功|已完成/.test(row.status)
    ).length;
    const errors = state.rows.filter((row) =>
      /失败|异常|未查到|需复核|超时/.test(row.status)
    ).length;
    const pending = state.rows.filter(
      (row) => !row.skip && !/成功|已完成|失败|异常|未查到|需复核|超时/.test(row.status)
    ).length;
    elements.totalCount.textContent = String(total);
    elements.successCount.textContent = String(success);
    elements.errorCount.textContent = String(errors);
    elements.pendingCount.textContent = String(pending);
  }

  function rowDisplayStatus(row) {
    return row.status || row.inputStatus || "待处理";
  }

  function renderRows() {
    elements.rowsBody.replaceChildren();
    if (!state.rows.length) {
      const tr = document.createElement("tr");
      tr.className = "empty-row";
      const td = document.createElement("td");
      td.colSpan = 5;
      td.textContent = "导入 Excel 后显示任务";
      tr.appendChild(td);
      elements.rowsBody.appendChild(tr);
      refreshProgress();
      return;
    }

    for (const row of state.rows) {
      const tr = document.createElement("tr");
      if (row.active) tr.classList.add("row-active");
      if (/失败|异常|超时|需复核/.test(rowDisplayStatus(row))) {
        tr.classList.add("row-error");
      }

      const values = [
        String(row.serial || row.originalRowIndex),
        row.inputId,
        row.category || "—",
        row.skc || "—",
        rowDisplayStatus(row)
      ];
      for (const value of values) {
        const td = document.createElement("td");
        td.textContent = value;
        tr.appendChild(td);
      }
      elements.rowsBody.appendChild(tr);
    }
    refreshProgress();
  }

  function updateRow(row, changes) {
    Object.assign(row, changes);
    renderRows();
  }

  function findColumn(headers, aliases) {
    return headers.findIndex((header) => aliases.includes(normalizeHeader(header)));
  }

  async function importWorkbook(file) {
    if (!file) return;
    const buffer = await file.arrayBuffer();
    const workbook = XLSX.read(buffer, { type: "array", cellDates: false });
    const sheetName = workbook.SheetNames[0];
    const sheet = workbook.Sheets[sheetName];
    const aoa = XLSX.utils.sheet_to_json(sheet, {
      header: 1,
      defval: "",
      raw: false
    });
    if (aoa.length < 2) throw new Error("Excel 没有可处理的数据行");

    const headers = aoa[0];
    const serialColumn = findColumn(headers, ["序号", "sequence", "no", "number"]);
    const spuColumn = findColumn(headers, [
      "spuid",
      "spu",
      "spu编号"
    ]);
    const skcColumn = findColumn(headers, [
      "skcid",
      "sckid",
      "skc",
      "sck",
      "skc编号"
    ]);
    const statusColumn = findColumn(headers, ["状态", "status"]);
    const inputColumn = spuColumn >= 0 ? spuColumn : skcColumn;
    const lookupType = spuColumn >= 0 ? "SPU" : "SKC";

    if (inputColumn < 0) {
      throw new Error("未找到“SPU ID”列，请使用 A 序号、B SPU ID、C 状态的格式");
    }

    const seenInput = new Set();
    const rows = [];
    for (let rowIndex = 1; rowIndex < aoa.length; rowIndex += 1) {
      const sourceRow = aoa[rowIndex] || [];
      const inputId = normalizeText(sourceRow[inputColumn]).replace(/\.0$/, "");
      const serial = normalizeText(sourceRow[serialColumn >= 0 ? serialColumn : 0]);
      const inputStatus = normalizeText(sourceRow[statusColumn >= 0 ? statusColumn : 2]);
      if (!inputId && !serial) continue;

      const row = {
        originalRowIndex: rowIndex,
        sourceRowIndex: rowIndex + 1,
        serial,
        inputId,
        lookupType,
        inputStatus,
        status: inputStatus || "待处理",
        skip: false,
        active: false,
        spu: lookupType === "SPU" ? inputId : "",
        skc: lookupType === "SKC" ? inputId : "",
        goodsCode: "",
        category: "",
        imagePath: "",
        imageReused: false,
        downlistOutcome: "",
        verified: false,
        error: ""
      };

      if (!/^\d{8,20}$/.test(inputId)) {
        row.skip = true;
        row.status = `${lookupType}格式异常`;
        row.error = `无效 ${lookupType}：${inputId || "空"}`;
      } else if (seenInput.has(inputId)) {
        row.skip = true;
        row.status = "重复，已跳过";
      } else if (statusIsSuccessful(inputStatus)) {
        row.skip = true;
        row.status = `表内已成功，跳过`;
      } else {
        seenInput.add(inputId);
      }
      rows.push(row);
    }

    Object.assign(state, {
      workbook,
      originalAoa: aoa,
      fileName: file.name,
      sheetName,
      columns: { serial: serialColumn, input: inputColumn, status: statusColumn },
      lookupType,
      rows,
      progressCurrent: 0,
      progressTotal: rows.filter((row) => !row.skip).length,
      lastResultPath: ""
    });
    elements.fileMeta.textContent = file.name;
    setRunState("已导入");
    renderRows();
    setButtons();
    log(`已导入 ${file.name}，有效任务 ${state.progressTotal} 条`);
  }

  async function nativeRequest(payload) {
    const response = await chrome.runtime.sendMessage({ type: "native", payload });
    if (!response?.ok) throw new Error(response?.error || "本地助手请求失败");
    if (!response.data?.success) {
      throw new Error(response.data?.error || "本地助手返回失败");
    }
    return response.data;
  }

  async function openProfile() {
    const browserId = normalizeText(elements.browserIdInput.value);
    if (!browserId) throw new Error("高级设置中未填写 BitBrowser ID");
    await chrome.storage.local.set({ advancedBrowserId: browserId });
    const response = await chrome.runtime.sendMessage({
      type: "openBitBrowserProfile",
      browserId
    });
    if (!response?.ok) throw new Error(response?.error || "打开比特浏览器失败");
    return response.data;
  }

  function isTemuUrl(url) {
    return /^https:\/\/agentseller(?:-eu)?\.temu\.com\//.test(url || "");
  }

  async function getOrCreateWorkTab(targetUrl) {
    const tabs = await chrome.tabs.query({});
    let tab = tabs.find((item) => item.url?.includes("/material/image-task"));
    if (!tab) tab = tabs.find((item) => isTemuUrl(item.url));
    if (!tab) {
      tab = await chrome.tabs.create({ url: targetUrl, active: true });
    } else if (targetUrl && tab.url !== targetUrl) {
      tab = await chrome.tabs.update(tab.id, { url: targetUrl, active: true });
    } else {
      await chrome.tabs.update(tab.id, { active: true });
    }
    state.workTabId = tab.id;

    const startedAt = Date.now();
    let reloadedForInjection = false;
    const deadline = Date.now() + 20000;
    while (Date.now() < deadline) {
      const current = await chrome.tabs.get(tab.id).catch(() => null);
      if (current?.status === "complete") {
        const ping = await sendToTab(tab.id, { type: "contentPing" }, false);
        if (ping?.ok) return current;
      }
      if (!reloadedForInjection && Date.now() - startedAt >= 7000) {
        reloadedForInjection = true;
        await chrome.tabs.reload(tab.id).catch(() => {});
      }
      await sleep(300);
    }
    throw new Error("Temu 页面加载或扩展脚本注入超时");
  }

  async function sendToTab(tabId, message, throwOnError = true) {
    try {
      let response = await chrome.tabs.sendMessage(tabId, message);
      if (!response) {
        await chrome.scripting.executeScript({
          target: { tabId },
          func: () => {
            delete globalThis.__temuDownlistContentLoaded;
          }
        });
        await chrome.scripting.executeScript({
          target: { tabId },
          files: ["shared.js", "content.js"]
        });
        await sleep(250);
        response = await chrome.tabs.sendMessage(tabId, message);
      }
      if (throwOnError && !response?.ok) {
        const error = new Error(response?.error || "页面操作失败");
        error.code = response?.code || "TAB_MESSAGE_FAILED";
        throw error;
      }
      return response;
    } catch (error) {
      if (!throwOnError) return null;
      throw error;
    }
  }

  async function checkEnvironment() {
    elements.checkEnvironmentBtn.disabled = true;
    setDot(elements.nativeDot, "");
    setDot(elements.browserDot, "");
    setDot(elements.pageDot, "");

    try {
      const nativeInfo = await nativeRequest({ action: "ping" });
      elements.nativeStatus.textContent = "已连接";
      setDot(elements.nativeDot, "ok");
      log(`本地助手已连接，输出目录：${nativeInfo.root}`);
    } catch (error) {
      elements.nativeStatus.textContent = "未安装/未启动";
      setDot(elements.nativeDot, "error");
      log(
        "本地助手未连接。请在解压后的插件目录双击“安装本地助手.cmd”，完成后完全退出并重新打开比特浏览器。详细错误：" +
          error.message,
        "error"
      );
    }

    const advancedBrowserId = normalizeText(elements.browserIdInput.value);
    if (advancedBrowserId) {
      try {
        const profile = await openProfile();
        elements.browserStatus.textContent = profile.name || "指定窗口";
        elements.profileDetail.textContent = `指定窗口：序号 ${profile.seq || "-"} / ${profile.name || "-"}`;
        setDot(elements.browserDot, "ok");
      } catch (error) {
        elements.browserStatus.textContent = "使用当前窗口";
        setDot(elements.browserDot, "ok");
        log(`指定比特窗口无法打开，继续使用当前 Temu 页面：${error.message}`, "warn");
      }
    } else {
      elements.browserStatus.textContent = "使用当前窗口";
      setDot(elements.browserDot, "ok");
      elements.profileDetail.textContent = "默认操作当前已打开的 Temu 页面";
    }

    try {
      await getOrCreateWorkTab(IMAGE_TASK_URL);
      elements.pageStatus.textContent = "已就绪";
      setDot(elements.pageDot, "ok");
    } catch (error) {
      elements.pageStatus.textContent = "未就绪";
      setDot(elements.pageDot, "error");
      log(error.message, "error");
    }

    elements.checkEnvironmentBtn.disabled = false;
  }

  async function ensurePausePoint() {
    while (state.paused && !state.stopping) await sleep(300);
    if (state.stopping) throw new Error("任务已由用户停止");
  }

  async function runOneRow(row) {
    row.active = true;
    updateRow(row, { status: "查询中", error: "" });
    await ensurePausePoint();

    const response = await sendToTab(state.workTabId, {
      type: "searchAndExtract",
      queryType: row.lookupType,
      id: row.inputId
    });
    const data = response.data;
    if (!data.found) {
      updateRow(row, {
        active: false,
        status: "未查到",
        error: `当前窗口没有该 ${row.lookupType} 的图片任务记录`
      });
      return;
    }

    const category = deriveCategoryCode(data.goodsCode, state.override);
    if (!category) {
      throw new Error(`无法从货号 ${data.goodsCode || "空"} 提取分类`);
    }

    updateRow(row, {
      spu: data.spu,
      skc: data.skc,
      goodsCode: data.goodsCode,
      category,
      status: "保存主图"
    });

    await nativeRequest({ action: "ensureFolders", category });
    const extension = inferImageExtension(data.mainImageUrl);
    const filename = `${data.spu}_主图_01.${extension}`;
    const saved = await nativeRequest({
      action: "saveImage",
      category,
      filename,
      url: data.mainImageUrl
    });
    updateRow(row, {
      imagePath: saved.path,
      imageReused: Boolean(saved.reused),
      status: saved.reused ? "主图已存在，复用" : "主图成功"
    });

    if (state.mode !== "downlist") {
      updateRow(row, { active: false, status: "演练完成（主图成功）" });
      return;
    }

    updateRow(row, { status: "提交下架" });
    let downlistResult = null;
    for (let attempt = 1; attempt <= 3; attempt += 1) {
      await ensurePausePoint();
      const result = await sendToTab(state.workTabId, {
        type: "downlistSkc",
        skc: row.skc,
        authorized: true
      });
      downlistResult = result.data;
      if (downlistResult.outcome === "success") break;
      if (downlistResult.outcome !== "busy" || attempt === 3) break;
      updateRow(row, {
        status: `平台忙碌，${attempt}/3 次后重试`
      });
      log(`SKC ${row.skc} 平台忙碌，15 秒后重试`, "warn");
      await sleep(15000);
    }

    if (downlistResult?.outcome === "success") {
      updateRow(row, {
        active: false,
        status: "下架成功",
        downlistOutcome: "success",
        error: ""
      });
      return;
    }

    const message =
      downlistResult?.outcome === "busy"
        ? "平台连续 3 次返回系统忙碌"
        : downlistResult?.message || "下架未获得成功结果";
    updateRow(row, {
      active: false,
      status: "下架失败",
      downlistOutcome: downlistResult?.outcome || "failed",
      error: message
    });
  }

  async function verifyDownlistResults() {
    const rows = state.rows.filter(
      (row) => row.downlistOutcome === "success" && !row.skip
    );
    if (!rows.length) return;

    try {
      await getOrCreateWorkTab(PRODUCT_LIST_URL);
      for (const row of rows) {
        await ensurePausePoint();
        updateRow(row, { status: "核验商品列表" });
        try {
          const response = await sendToTab(state.workTabId, {
            type: "verifyDownlisted",
            skc: row.skc
          });
          if (response.data?.verified) {
            updateRow(row, {
              verified: true,
              status: "下架成功（已核验）"
            });
          } else {
            updateRow(row, {
              verified: false,
              status: "需复核（列表未确认）",
              error: response.data?.reason || "商品列表未在已下架分类中确认"
            });
          }
        } catch (error) {
          updateRow(row, {
            verified: false,
            status: "需复核（核验失败）",
            error: error.message
          });
        }
      }
    } catch (error) {
      log(`商品列表核验未完成：${error.message}`, "warn");
    }
  }

  function buildResultWorkbook() {
    const aoa = state.originalAoa.map((row) => [...row]);
    const headers = aoa[0] || [];
    const extraStart = Math.max(headers.length, 3);
    headers[extraStart] = "输入类型";
    headers[extraStart + 1] = "输入ID";
    headers[extraStart + 2] = "SPU";
    headers[extraStart + 3] = "SKC";
    headers[extraStart + 4] = "货号分类";
    headers[extraStart + 5] = "页面货号";
    headers[extraStart + 6] = "主图文件";
    headers[extraStart + 7] = "下架结果";
    headers[extraStart + 8] = "错误信息";
    aoa[0] = headers;

    for (const row of state.rows) {
      const target = aoa[row.originalRowIndex] || [];
      const statusColumn = state.columns.status >= 0 ? state.columns.status : 2;
      target[statusColumn] = rowDisplayStatus(row);
      target[extraStart] = row.lookupType;
      target[extraStart + 1] = row.inputId;
      target[extraStart + 2] = row.spu;
      target[extraStart + 3] = row.skc;
      target[extraStart + 4] = row.category;
      target[extraStart + 5] = row.goodsCode;
      target[extraStart + 6] = row.imagePath;
      target[extraStart + 7] = row.downlistOutcome;
      target[extraStart + 8] = row.error;
      aoa[row.originalRowIndex] = target;
    }

    const worksheet = XLSX.utils.aoa_to_sheet(aoa);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, maybeSheetName(state.sheetName));
    return XLSX.write(workbook, { type: "base64", bookType: "xlsx" });
  }

  function maybeSheetName(name) {
    return String(name || "处理结果").replace(/[\\/?*\[\]:]/g, "_").slice(0, 31);
  }

  async function exportResults() {
    if (!state.originalAoa.length) throw new Error("尚未导入 Excel");
    const base64 = buildResultWorkbook();
    const relativePath = `处理结果_${formatDateTime()}.xlsx`;
    const saved = await nativeRequest({
      action: "saveFile",
      relativePath,
      base64
    });
    state.lastResultPath = saved.path;
    log(`结果表已保存：${saved.path}`);
    return saved.path;
  }

  async function startBatch() {
    if (state.running || !state.rows.length) return;
    state.override = normalizeText(elements.categoryOverrideInput.value).toUpperCase();

    if (state.mode === "downlist") {
      if (!elements.authorizeSubmitInput.checked) {
        throw new Error("请勾选“允许自动提交下架”后再开始");
      }
      const confirmed = window.confirm(
        `本批将真实提交下架，最终确认后商品可能无法恢复。\n\n有效任务：${state.progressTotal} 条\n输出：桌面\\下架图片合集\\{货号分类}\\...\n\n确定继续？`
      );
      if (!confirmed) return;
    }

    state.running = true;
    state.paused = false;
    state.stopping = false;
    state.progressCurrent = 0;
    setButtons();
    setRunState("检查运行环境");

    try {
      await nativeRequest({ action: "ping" });
      const advancedBrowserId = normalizeText(elements.browserIdInput.value);
      if (advancedBrowserId) {
        try {
          await openProfile();
        } catch (error) {
          const tabs = await chrome.tabs.query({});
          if (!tabs.some((tab) => isTemuUrl(tab.url))) {
            throw new Error(`当前没有 Temu 页面，指定比特窗口也不可用：${error.message}`);
          }
          log(`指定比特窗口无法打开，继续使用当前 Temu 页面：${error.message}`, "warn");
        }
      }
      await getOrCreateWorkTab(IMAGE_TASK_URL);

      const queued = state.rows.filter((row) => !row.skip);
      state.progressTotal = queued.length;
      refreshProgress();
      for (let index = 0; index < queued.length; index += 1) {
        if (state.stopping) break;
        await ensurePausePoint();
        const row = queued[index];
        setRunState(`处理 ${row.lookupType} ${row.inputId}`);
        log(`开始处理第 ${index + 1}/${queued.length} 条：${row.lookupType} ${row.inputId}`);
        try {
          await runOneRow(row);
        } catch (error) {
          updateRow(row, {
            active: false,
            status: "处理失败",
            error: error.message
          });
          log(`${row.lookupType} ${row.inputId} 失败：${error.message}`, "error");
        }
        state.progressCurrent = index + 1;
        refreshProgress();
      }

      if (state.mode === "downlist" && !state.stopping) {
        setRunState("核验下架结果");
        await verifyDownlistResults();
      }

      setRunState(state.stopping ? "已停止" : "已完成");
      await exportResults();
    } catch (error) {
      setRunState("批处理异常");
      log(error.message, "error");
    } finally {
      state.running = false;
      state.paused = false;
      state.stopping = false;
      for (const row of state.rows) row.active = false;
      renderRows();
      setButtons();
    }
  }

  function togglePause() {
    if (!state.running) return;
    state.paused = !state.paused;
    setRunState(state.paused ? "已暂停" : "继续处理");
    log(state.paused ? "任务已暂停" : "任务继续");
    setButtons();
  }

  function stopBatch() {
    if (!state.running) return;
    state.stopping = true;
    state.paused = false;
    setRunState("正在停止");
    log("已请求停止，将在当前页面动作结束后停止", "warn");
    setButtons();
  }

  function bindEvents() {
    document.querySelectorAll('input[name="mode"]').forEach((radio) => {
      radio.addEventListener("change", () => {
        if (!radio.checked) return;
        state.mode = radio.value;
        elements.authorizeWrap.classList.toggle("hidden", state.mode !== "downlist");
      });
    });

    elements.browserIdInput.addEventListener("change", async () => {
      await chrome.storage.local.set({
        advancedBrowserId: normalizeText(elements.browserIdInput.value)
      });
    });
    elements.categoryOverrideInput.addEventListener("change", async () => {
      state.override = normalizeText(elements.categoryOverrideInput.value).toUpperCase();
      await chrome.storage.local.set({ categoryOverride: state.override });
    });
    elements.checkEnvironmentBtn.addEventListener("click", checkEnvironment);
    elements.startBtn.addEventListener("click", () =>
      startBatch().catch((error) => log(error.message, "error"))
    );
    elements.pauseBtn.addEventListener("click", togglePause);
    elements.stopBtn.addEventListener("click", stopBatch);
    elements.exportBtn.addEventListener("click", () =>
      exportResults().catch((error) => log(error.message, "error"))
    );
    elements.clearLogBtn.addEventListener("click", () => {
      elements.logOutput.textContent = "";
    });
    document.querySelectorAll(".skin-swatch").forEach((button) => {
      button.addEventListener("click", () => applyTheme(button.dataset.theme));
    });
    elements.excelInput.addEventListener("change", async () => {
      try {
        await importWorkbook(elements.excelInput.files?.[0]);
      } catch (error) {
        elements.fileMeta.textContent = "导入失败";
        log(error.message, "error");
      }
    });
  }

  async function init() {
    const stored = await chrome.storage.local.get([
      "advancedBrowserId",
      "categoryOverride",
      "skin"
    ]);
    elements.browserIdInput.value = stored.advancedBrowserId || "";
    elements.categoryOverrideInput.value = stored.categoryOverride || "";
    state.override = normalizeText(elements.categoryOverrideInput.value).toUpperCase();
    applyTheme(stored.skin || "classic", false);
    bindEvents();
    renderRows();
    setButtons();
    log("扩展已加载。先安装本地助手，再检查运行环境。");
  }

  init().catch((error) => log(error.message, "error"));
})();
